// ============================================
// RCM Controller - Cordova BLE App (Clean)
// ============================================

const SERVICE_UUID = "8f41ca5d-f679-45bb-a603-9bc1c5eedefc";
const COMMAND_UUID = "0000abcd-0000-1000-8000-00805f9b34fb";
const RESPONSE_UUID = "0000dcba-0000-1000-8000-00805f9b34fb";

let bleDevice = null;
let isConnected = false;
let selectedPayload = null;
let payloadList = [];
let responseBuffer = "";
let isScanning = false;
let notifyEnabled = false;

const els = {
    statusText: document.getElementById('statusText'),
    deviceName: document.getElementById('deviceName'),
    connectionStatus: document.getElementById('connectionStatus'),
    scanBtn: document.getElementById('scanBtn'),
    disconnectBtn: document.getElementById('disconnectBtn'),
    scanSpinner: document.getElementById('scanSpinner'),
    ipAddress: document.getElementById('ipAddress'),
    ipStatus: document.getElementById('ipStatus'),
    payloadList: document.getElementById('payloadList'),
    noPayloads: document.getElementById('noPayloads'),
    getIpBtn: document.getElementById('getIpBtn'),
    listBtn: document.getElementById('listBtn'),
    rebootBtn: document.getElementById('rebootBtn'),
    openWebBtn: document.getElementById('openWebBtn'),
    statusMsg: document.getElementById('statusMsg')
};

document.addEventListener('deviceready', onDeviceReady, false);

function onDeviceReady() {
    console.log('=== DEVICE READY ===');
    if (window.StatusBar) StatusBar.styleLightContent();
    updateConnectionUI(false);
    checkPermissions();
}

// ============================================
// PERMISSION CHECKS (Using cordova.plugins.diagnostic)
// ============================================

function checkPermissions() {
    // Don't re-check if already scanning or connected
    if (isScanning || isConnected) return;
    
    updateStatus('scanning', 'Checking Bluetooth...');
    showStatus('Checking permissions...', true);
    els.scanBtn.disabled = true;
    
    checkBluetooth();
}

function checkBluetooth() {
    if (typeof ble === 'undefined') {
        showStatus('BLE plugin not loaded', false);
        return;
    }
    
    ble.isEnabled(
        () => {
            console.log('Bluetooth is ON');
            checkLocation();
        },
        () => {
            console.log('Bluetooth is OFF');
            handleBluetoothOff();
        }
    );
}

function handleBluetoothOff() {
    updateStatus('disconnected', 'Bluetooth disabled');
    showStatus('Bluetooth is off', false);
    els.scanBtn.disabled = true;
    
    setTimeout(() => {
        if (confirm('Bluetooth is disabled.\n\nThis app needs Bluetooth to connect to the ESP32.\n\nTap OK to open Bluetooth Settings.')) {
            cordova.plugins.diagnostic.switchToBluetoothSettings();
        }
    }, 300);
}

function checkLocation() {
    if (!cordova.plugins || !cordova.plugins.diagnostic) {
        console.log('Diagnostic plugin not available, skipping location check');
        allChecksPassed();
        return;
    }
    
    cordova.plugins.diagnostic.isLocationEnabled(
        (enabled) => {
            if (enabled) {
                console.log('Location is ON');
                allChecksPassed();
            } else {
                console.log('Location is OFF');
                handleLocationOff();
            }
        },
        (error) => {
            console.error('Location check error:', error);
            allChecksPassed();
        }
    );
}

function handleLocationOff() {
    updateStatus('disconnected', 'Location disabled');
    showStatus('Location is off', false);
    els.scanBtn.disabled = true;
    
    setTimeout(() => {
        if (confirm('Location services are disabled.\n\nAndroid requires Location to be ON for Bluetooth LE scanning.\n\nTap OK to open Location Settings.')) {
            cordova.plugins.diagnostic.switchToLocationSettings();
        }
    }, 300);
}

function allChecksPassed() {
    updateStatus('disconnected', 'Ready to scan');
    showStatus('Ready — tap Scan & Connect', true);
    els.scanBtn.disabled = false;
}

// ============================================
// CONNECTION
// ============================================


function scanAndConnect() {
    if (isScanning) return;
    
    if (typeof ble === 'undefined') {
        showStatus('Bluetooth not available', false);
        return;
    }
    
    // Re-check permissions before scanning
    els.scanBtn.disabled = true;
    updateStatus('scanning', 'Checking...');
    
    ble.isEnabled(
        () => {
            if (cordova.plugins && cordova.plugins.diagnostic) {
                cordova.plugins.diagnostic.isLocationEnabled(
                    (enabled) => {
                        if (enabled) {
                            startScan();
                        } else {
                            handleLocationOff();
                        }
                    },
                    () => startScan()
                );
            } else {
                startScan();
            }
        },
        () => {
            handleBluetoothOff();
        }
    );
}

function startScan() {
    isScanning = true;
    els.scanBtn.disabled = true;
    els.scanSpinner.style.display = 'block';
    updateStatus('scanning', 'Scanning...');
    showStatus('Looking for Switch Modchip...', true);
    
    console.log('Starting BLE scan with SERVICE_UUID filter...');
    
    // Try service UUID filter first
    ble.scan([SERVICE_UUID], 8, onScanResult, onScanError);
    
    // Fallback: if no device found by UUID, scan all and match by name
    setTimeout(() => {
        if (isScanning && !isConnected) {
            console.log('No service match — falling back to name scan');
            ble.stopScan();
            
            ble.scan([], 8, (device) => {
            	const deviceName = device.name || '';
            	// Match "Modchip" anywhere in the name, ignoring the IP part
            	if (deviceName.indexOf('Modchip') !== -1) {
            		console.log('Found Modchip:', deviceName);
            		ble.stopScan();
            		isScanning = false;
            		connectToDevice(device);
            	}
            }, onScanError);
        }
    }, 8500);
    
    // Overall timeout
    setTimeout(() => {
        if (isScanning && !isConnected) {
            ble.stopScan();
            isScanning = false;
            els.scanBtn.disabled = false;
            els.scanSpinner.style.display = 'none';
            updateStatus('disconnected', 'No device found');
            showStatus('No Switch Modchip found. Is it powered on?', false);
        }
    }, 17000);
}

function onScanResult(device) {
    // With SERVICE_UUID filter, any device found is valid — no name check needed
    console.log('Found device with matching service:', device.name || '(no name)', 'ID:', device.id);
    
    ble.stopScan();
    isScanning = false;
    connectToDevice(device);
}

function onScanError(error) {
    console.error('Scan error:', error);
    isScanning = false;
    els.scanBtn.disabled = false;
    els.scanSpinner.style.display = 'none';
    updateStatus('disconnected', 'Scan failed');
    showStatus('Scan error: ' + JSON.stringify(error), false);
}

function connectToDevice(device) {
    updateStatus('scanning', 'Connecting to ' + (device.name || 'device') + '...');
    console.log('Connecting to:', device.id);
    
    ble.connect(device.id, 
        () => onConnectSuccess(device),
        (err) => onConnectError(err)
    );
}

function onConnectSuccess(device) {
    console.log('=== CONNECT SUCCESS ===');
    
    bleDevice = device;
    isConnected = true;
    isScanning = false;
    
    els.scanSpinner.style.display = 'none';
    
    updateConnectionUI(true);
    updateStatus('connected', 'Connected');
    showStatus('Connected to ' + (device.name || 'device'), true);
    
    // Request larger MTU (512 - 3 bytes ATT header = 509 bytes payload)
    setTimeout(() => {
        requestMtu(512);
    }, 300);
    
    setTimeout(() => {
        enableNotifications();
    }, 800);
}

function requestMtu(mtuSize) {
    if (!bleDevice) return;
    
    console.log('Requesting MTU:', mtuSize);
    
    // cordova-plugin-ble-central supports requestMtu on Android
    if (ble.requestMtu) {
        ble.requestMtu(bleDevice.id, mtuSize,
            (newMtu) => {
                console.log('MTU negotiated:', newMtu);
                showStatus('MTU set to ' + newMtu + ' bytes', true);
            },
            (err) => {
                console.error('MTU request failed:', err);
                // Fall back to default 20 bytes — app still works, just slower
            }
        );
    } else {
        console.log('requestMtu not available in this plugin version');
    }
}

function enableNotifications() {
    if (!bleDevice) return;
    
    console.log('Enabling notifications...');
    
    ble.startNotification(bleDevice.id, SERVICE_UUID, RESPONSE_UUID, 
        (buffer) => {
            if (!notifyEnabled) {
                notifyEnabled = true;
                console.log('Notifications ACTIVE');
            }
            onDataReceived(buffer);
        },
        (err) => {
            console.error('Notification setup FAILED:', err);
            showStatus('Notify failed: ' + JSON.stringify(err), false);
        }
    );
    
    setTimeout(() => {
        console.log('Sending initial GETIP...');
        sendCommand('GETIP');
    }, 800);
}

function onConnectError(error) {
    console.error('=== CONNECT FAILED ===', error);
    isConnected = false;
    bleDevice = null;
    isScanning = false;
    
    els.scanBtn.disabled = false;
    els.scanSpinner.style.display = 'none';
    updateStatus('disconnected', 'Connection failed');
    showStatus('Connection failed: ' + JSON.stringify(error), false);
}

function disconnect() {
    if (!bleDevice) return;
    
    console.log('Disconnecting...');
    notifyEnabled = false;
    
    ble.disconnect(bleDevice.id, () => {
        onDisconnected();
    }, () => {
        onDisconnected();
    });
}

function onDisconnected() {
    console.log('=== DISCONNECTED ===');
    isConnected = false;
    bleDevice = null;
    notifyEnabled = false;
    responseBuffer = "";
    payloadList = [];
    selectedPayload = null;
    
    updateConnectionUI(false);
    updateStatus('disconnected', 'Disconnected');
    renderPayloadList();
}

// ============================================
// DATA HANDLING
// ============================================

function onDataReceived(buffer) {
    const data = bytesToString(buffer);
    console.log('=== BLE RX ===', JSON.stringify(data));
    
    responseBuffer += data;
    
    let newlineIndex;
    while ((newlineIndex = responseBuffer.indexOf('\n')) !== -1) {
        const line = responseBuffer.substring(0, newlineIndex).trim();
        responseBuffer = responseBuffer.substring(newlineIndex + 1);
        
        if (line) {
            console.log('Processing line:', JSON.stringify(line));
            processLine(line);
        }
    }
    
    if (responseBuffer.length > 0) {
        const trimmed = responseBuffer.trim();
        
        if (isValidIP(trimmed)) {
            processLine(trimmed);
            responseBuffer = "";
            return;
        }
        
        if (trimmed === 'END') {
            processLine('END');
            responseBuffer = "";
            return;
        }
        
        if (trimmed === 'OK' || trimmed.startsWith('ERROR') || trimmed === 'UNKNOWN_CMD') {
            processLine(trimmed);
            responseBuffer = "";
            return;
        }
        
        if (trimmed.endsWith('.bin') && trimmed.length > 4) {
            processLine(trimmed);
            responseBuffer = "";
            return;
        }
        
        if (responseBuffer.length > 100) {
            processLine(trimmed);
            responseBuffer = "";
        }
    }
}

function processLine(line) {
    console.log('Process:', JSON.stringify(line));
    
    if (line === 'END') {
        console.log('List complete:', payloadList.length);
        if (payloadList.length === 0) {
            showStatus('No payloads found', false);
        } else {
            showStatus('Loaded ' + payloadList.length + ' payload(s)', true);
        }
        renderPayloadList();
        return;
    }
    
    if (line === 'OK') {
        showStatus('Payload Changed', true);
        return;
    }
    
    if (line.indexOf('ERROR') === 0) {
        showStatus('Device error: ' + line, false);
        return;
    }
    
    if (line === 'UNKNOWN_CMD') {
        showStatus('Unknown command', false);
        return;
    }
    
    if (isValidIP(line)) {
        console.log('IP detected:', line);
        els.ipAddress.textContent = line;
        els.ipStatus.textContent = 'Device IP Address';
        
        els.openWebBtn.style.display = 'inline-block';
        els.openWebBtn.disabled = false;
        
        showStatus('IP: ' + line, true);
        return;
    }
    
    if (line.endsWith('.bin')) {
        console.log('Payload found:', line);
        const exists = payloadList.some(p => p.name === line);
        if (!exists) {
            payloadList.push({ name: line, path: '/payloads/' + line });
            renderPayloadList();
        }
        return;
    }
    
    console.log('Unhandled line:', JSON.stringify(line));
}

function isValidIP(str) {
    const parts = str.split('.');
    if (parts.length !== 4) return false;
    return parts.every(p => {
        const n = parseInt(p, 10);
        return n >= 0 && n <= 255 && p === String(n);
    });
}

// ============================================
// COMMANDS
// ============================================

function sendCommand(cmd) {
    if (!isConnected || !bleDevice) {
        showStatus('Not connected to device', false);
        return;
    }
    
    console.log('=== BLE TX ===', cmd);
    showStatus('Sending: ' + cmd + '...', true);
    
    responseBuffer = "";
    const buffer = stringToBytes(cmd);
    
    ble.writeWithoutResponse(bleDevice.id, SERVICE_UUID, COMMAND_UUID, buffer,
        () => {
            console.log('TX success:', cmd);
            
            if (cmd === 'REBOOT') {
                showStatus('Rebooting device...', true);
                setTimeout(() => {
                    disconnect();
                    showStatus('Device rebooted. Reconnect when ready.', true);
                }, 1000);
            } else if (cmd === 'LIST') {
                showStatus('Requesting payload list...', true);
                payloadList = [];
                renderPayloadList();
                els.payloadList.innerHTML = '<div style="text-align:center;color:#4db8ff;padding:20px;">Loading...</div>';
            } else if (cmd === 'GETIP') {
                showStatus('Requesting IP address...', true);
                els.ipAddress.textContent = 'Requesting...';
            }
        },
        (err) => {
            console.error('TX failed (writeWithoutResponse):', err);
            
            ble.write(bleDevice.id, SERVICE_UUID, COMMAND_UUID, buffer,
                () => console.log('TX fallback success:', cmd),
                (err2) => {
                    console.error('TX fallback failed:', err2);
                    showStatus('Send failed: ' + JSON.stringify(err2), false);
                }
            );
        }
    );
}

function openWebUI() {
    const ip = els.ipAddress.textContent.trim();
    
    if (!ip || ip === 'Not connected' || ip === 'Requesting...') {
        showStatus('No valid IP address available', false);
        return;
    }
    
    if (!isValidIP(ip)) {
        showStatus('Invalid IP address: ' + ip, false);
        return;
    }
    
    const url = 'http://' + ip;
    console.log('Opening browser to:', url);
    
    if (typeof cordova !== 'undefined' && cordova.InAppBrowser) {
        cordova.InAppBrowser.open(url, '_system');
    } else {
        window.open(url, '_system');
    }
    
    showStatus('Opening ' + url, true);
}

// ============================================
// UI
// ============================================

function renderPayloadList() {
    const container = els.payloadList;
    
    if (payloadList.length === 0) {
        container.innerHTML = '<div style="text-align:center;color:#aaa;padding:20px;">Press "List Payloads" to load available .bin files</div>';
        return;
    }
    
    container.innerHTML = '';
    
    payloadList.forEach(payload => {
        const item = document.createElement('div');
        item.className = 'payload-item';
        if (selectedPayload && selectedPayload.name === payload.name) {
            item.classList.add('selected');
        }
        
        item.innerHTML = '<div class="payload-icon">📄</div><div class="payload-name">' + escapeHtml(payload.name) + '</div>';
        item.onclick = function() { selectPayload(payload); };
        container.appendChild(item);
    });
}

function selectPayload(payload) {
    if (selectedPayload && selectedPayload.name === payload.name) {
        showStatus('Already selected: ' + payload.name, true);
        return;
    }
    
    selectedPayload = payload;
    renderPayloadList();
    
    const items = document.querySelectorAll('.payload-item');
    items.forEach(item => {
        const nameEl = item.querySelector('.payload-name');
        if (nameEl && nameEl.textContent === payload.name) {
            item.classList.add('sending');
            setTimeout(() => item.classList.remove('sending'), 600);
        }
    });
    
    const cmd = 'PLD:' + payload.name;
    console.log('Auto-sending:', cmd);
    showStatus('Selected: ' + payload.name, true);
    
    sendCommand(cmd);
}

function updateConnectionUI(connected) {
    els.scanBtn.style.display = connected ? 'none' : 'inline-block';
    els.disconnectBtn.style.display = connected ? 'inline-block' : 'none';
    
    els.scanBtn.disabled = connected;
    els.disconnectBtn.disabled = !connected;
    els.getIpBtn.disabled = !connected;
    els.listBtn.disabled = !connected;
    els.rebootBtn.disabled = !connected;
    
    if (!connected) {
        els.ipAddress.textContent = 'Not connected';
        els.ipStatus.textContent = 'Press refresh to get IP';
        els.openWebBtn.style.display = 'none';
        els.openWebBtn.disabled = true;
    }
}

function updateStatus(state, text) {
    els.connectionStatus.className = 'status-' + state;
    els.statusText.textContent = text;
    //els.deviceName.textContent = (state === 'connected' && bleDevice) ? ' (' + (bleDevice.name || 'device') + ')' : '';
    els.deviceName.textContent = (state === 'connected' && bleDevice) ? ' (' + ('Switch Modchip' || 'device') + ')' : '';
}

function showStatus(msg, success) {
    els.statusMsg.textContent = msg;
    els.statusMsg.className = 'status-box ' + (success ? 'status-success' : 'status-error');
    els.statusMsg.style.display = 'block';
    setTimeout(() => { els.statusMsg.style.display = 'none'; }, 4000);
    console.log('Status:', msg);
}

// ============================================
// UTILS
// ============================================

function stringToBytes(str) {
    const bytes = new Uint8Array(str.length);
    for (let i = 0; i < str.length; i++) bytes[i] = str.charCodeAt(i);
    return bytes.buffer;
}

function bytesToString(buffer) {
    const bytes = new Uint8Array(buffer);
    let result = '';
    for (let i = 0; i < bytes.length; i++) result += String.fromCharCode(bytes[i]);
    return result;
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// ============================================
// APP LIFECYCLE (Resume from Settings)
// ============================================

document.addEventListener('resume', onAppResume, false);

function onAppResume() {
    console.log('=== APP RESUMED ===');
    
    if (!isConnected && !isScanning) {
        console.log('Re-checking permissions after resume...');
        checkPermissions();
    }
}

document.addEventListener('backbutton', function(e) {
    if (isConnected) {
        e.preventDefault();
        disconnect();
    } else {
        navigator.app.exitApp();
    }
}, false);